# API reference

The live OpenAPI schema is served at `/openapi.json` and Swagger UI at `/docs`.

## `GET /api/health`

Returns service status and semantic version.

## `POST /api/analyze`

Request JSON:

```json
{"url":"https://github.com/owner/repository","max_commits":250}
```

`url` must be an HTTPS public GitHub repository URL without credentials, query, or fragment. `max_commits` is an integer from 1 through 2,000.

Success returns `repository`, `remote`, `branch`, `head`, `summary`, `timeline`, `files`, `graph.nodes`, `graph.edges`, `date_range`, and `notes`. Error codes include 422 for invalid or inaccessible repositories, 422 for schema validation, 504 for clone timeout, and 503 if Git is unavailable.

No local filesystem path or private access token is accepted by this endpoint.

## File history (engine and CLI in v0.2 development increment)

The shared engine exposes `analyze_file_history(path, file_path, max_commits=250)` for bounded, repository-relative file history. It uses Git's `--follow` heuristic. A dedicated HTTP endpoint is not yet exposed; use the CLI until that endpoint is added.

```bash
mindtrace file-history /path/to/repository src/app.py
mindtrace file-history /path/to/repository src/app.py --json file-history.json
```

## `POST /api/file-history`

Request body:

```json
{
  "url": "https://github.com/owner/repository",
  "file_path": "src/app.py",
  "max_commits": 250
}
```

Returns an array of file-history entries containing SHA, short SHA, author, date, subject, observed paths, and a GitHub commit URL when available. `file_path` must be repository-relative; parent traversal is rejected. Rename following uses Git's heuristic and is not guaranteed for all rename patterns. Public-repository clone limits and timeout behavior match `/api/analyze`.
