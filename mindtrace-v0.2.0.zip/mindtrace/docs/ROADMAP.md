# Roadmap

## v0.1.0 — implemented baseline

- [x] Local Git history extraction, commit timeline, author/date/path metadata
- [x] File change frequency counts
- [x] Bounded co-change graph
- [x] CLI JSON report
- [x] FastAPI public GitHub analysis endpoint
- [x] Responsive web report and interactive SVG graph
- [x] Tests, CI workflow, security and contributor docs

## Planned (not implemented)

- [ ] Rename-aware file lineage and per-file history view
- [ ] Historical diff inspection and line churn statistics
- [ ] Better merge-commit semantics and configurable first-parent traversal
- [ ] Statistically tested change-point detection with confidence/limitations
- [ ] Background analysis jobs, cancellation, and progress reporting
- [ ] Optional WebGL/Three.js artifact scene after performance and accessibility profiling
- [ ] Public deployment rate limiting, queueing, and hardened egress sandbox
- [ ] Exportable HTML/SARIF-like report formats

## v0.2.0 development increment

- Added a bounded `analyze_file_history` engine operation backed by `git log --follow`.
- Added `mindtrace file-history <repo> <path>` with human-readable and JSON output.
- The rename-follow behavior is Git's heuristic and is not guaranteed for every rename; history is still limited by `--max-commits`.
- Added `POST /api/file-history` for public GitHub repositories. A browser file-history panel remains planned.
