# Architecture

## Modules

- `git_reader.py`: bounded subprocess wrapper, timeouts, safe Git errors, repository validation.
- `engine.py`: extracts branch, HEAD, remote, commit metadata and changed paths; assembles shared report models.
- `graph.py`: creates a weighted, bounded co-change graph from paths observed together in a commit.
- `models.py`: Pydantic report contract shared by API and CLI.
- `cli.py`: local repository command line interface.
- `api.py`: FastAPI health/analyze endpoints, GitHub URL validation, temporary clone lifecycle, static web serving.
- `web/`: build-free responsive frontend; all report data comes from `/api/analyze`.

## Analysis semantics

File change count is the number of analyzed commits that list a path. Edge weight is the number of analyzed commits where both endpoint paths are present. Commit messages and authors are Git metadata, not semantic interpretations. The system currently reports descriptive signals rather than predictions.

## Resource bounds

`max_commits` is limited to 2,000. The graph keeps at most 80 nodes and 240 edges. Commits with more than 40 changed paths are omitted from pair generation. Public clone timeout is 45 seconds; individual Git metadata commands use a 20-second timeout.

## Trust boundaries

The API accepts a URL rather than a filesystem path. It only permits HTTPS `github.com` URLs in owner/repository form and clones into a temporary directory. It never runs repository code. Public deployment still requires network egress restrictions and resource controls because hostname validation alone does not fully prevent SSRF or abuse.
