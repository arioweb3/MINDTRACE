"""MINDTRACE: digital archaeology for Git repositories."""
__version__ = "0.1.0"
