"""Command-line interface for MINDTRACE."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from .engine import MAX_COMMITS, analyze_file_history, analyze_repository
from .git_reader import GitError

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mindtrace", description="Excavate a Git repository's real history.")
    sub = parser.add_subparsers(dest="command", required=True)
    analyze = sub.add_parser("analyze", help="Analyze a local Git repository")
    analyze.add_argument("repository", type=Path, help="Path to a local Git checkout")
    analyze.add_argument("--max-commits", type=int, default=250, choices=range(1, MAX_COMMITS + 1), metavar="N")
    analyze.add_argument("--json", dest="json_path", metavar="FILE", help="Write the full report to a JSON file (use - for stdout)")
    history = sub.add_parser("file-history", help="Inspect history for one repository-relative file")
    history.add_argument("repository", type=Path, help="Path to a local Git checkout")
    history.add_argument("file", help="Repository-relative file path")
    history.add_argument("--max-commits", type=int, default=250, choices=range(1, MAX_COMMITS + 1), metavar="N")
    history.add_argument("--json", dest="json_path", metavar="FILE", help="Write JSON to a file (use - for stdout)")
    return parser

def main() -> None:
    args = build_parser().parse_args()
    try:
        if args.command == "file-history":
            entries = analyze_file_history(args.repository, args.file, max_commits=args.max_commits)
            payload = [entry.model_dump(mode="json") for entry in entries]
            if args.json_path:
                rendered = json.dumps(payload, indent=2, ensure_ascii=False) + "\n"
                if args.json_path == "-":
                    print(rendered, end="")
                else:
                    output = Path(args.json_path).expanduser()
                    output.write_text(rendered, encoding="utf-8")
                    print(f"File history written to {output}")
            else:
                print(f"MINDTRACE // file history: {args.file}")
                for entry in entries:
                    print(f"{entry.short_sha}  {entry.date.isoformat()}  {entry.author}  {entry.subject}")
                print(f"\n{len(entries)} historical commits found.")
            return
        report = analyze_repository(args.repository, max_commits=args.max_commits)
    except (GitError, ValueError) as exc:
        print(f"mindtrace: error: {exc}", file=sys.stderr)
        raise SystemExit(2) from exc
    payload = report.model_dump(mode="json")
    if args.json_path:
        rendered = json.dumps(payload, indent=2, ensure_ascii=False) + "\n"
        if args.json_path == "-":
            print(rendered, end="")
        else:
            Path(args.json_path).expanduser().write_text(rendered, encoding="utf-8")
            print(f"Report written to {Path(args.json_path).expanduser()}")
    else:
        print(f"MINDTRACE // {report.repository}")
        print(f"Commits analyzed : {report.summary.commits_analyzed}")
        print(f"Files touched    : {report.summary.files_touched}")
        print(f"Contributors     : {report.summary.contributors}")
        print(f"Co-change links  : {report.summary.cochange_links}")
        print("\nMost changed files")
        for item in report.files[:10]:
            print(f"  {item.change_count:>4}  {item.path}")
        print("\nNote: co-change is correlation in commit history, not proof of dependency.")
if __name__ == "__main__":
    main()
