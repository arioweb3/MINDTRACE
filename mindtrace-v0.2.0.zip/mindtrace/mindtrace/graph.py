"""Co-change graph built from observed shared commits, not inferred dependencies."""
from __future__ import annotations
from collections import Counter
from itertools import combinations
from .models import GraphEdge, GraphNode

MAX_FILES_PER_COMMIT = 40
MAX_GRAPH_NODES = 80
MAX_GRAPH_EDGES = 240

def build_cochange_graph(file_counts: Counter[str], commit_files: list[list[str]], *,
                         max_nodes: int = MAX_GRAPH_NODES, max_edges: int = MAX_GRAPH_EDGES,
                         max_files_per_commit: int = MAX_FILES_PER_COMMIT) -> tuple[list[GraphNode], list[GraphEdge]]:
    """Build a bounded weighted graph; an edge means co-change observations only."""
    selected = [p for p, _ in file_counts.most_common(max_nodes)]
    allowed = set(selected)
    weights: Counter[tuple[str, str]] = Counter()
    for paths in commit_files:
        unique = sorted({p for p in paths if p in allowed})
        # Skip oversized commits rather than generating a quadratic explosion.
        if len(unique) > max_files_per_commit:
            continue
        weights.update(combinations(unique, 2))
    edges = [GraphEdge(source=a, target=b, weight=w)
             for (a, b), w in weights.most_common(max_edges)]
    nodes = [GraphNode(id=p, path=p, change_count=file_counts[p]) for p in selected]
    return nodes, edges
