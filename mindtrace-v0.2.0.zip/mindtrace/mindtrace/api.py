"""FastAPI application and public GitHub repository ingestion."""
from __future__ import annotations
import re
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import urlparse
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from . import __version__
from .engine import MAX_COMMITS, analyze_file_history, analyze_repository
from .git_reader import GitError

app = FastAPI(title="MINDTRACE API", version=__version__, description="Explore real Git history and observed co-change patterns.")

class AnalyzeRequest(BaseModel):
    url: str = Field(max_length=300)
    max_commits: int = Field(default=250, ge=1, le=MAX_COMMITS)

    @field_validator("url")
    @classmethod
    def validate_github_url(cls, value: str) -> str:
        parsed = urlparse(value.strip())
        if parsed.scheme != "https" or parsed.hostname != "github.com" or parsed.port not in (None, 443):
            raise ValueError("Only public HTTPS URLs on github.com are accepted.")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Credentials, query strings, and fragments are not allowed.")
        path = parsed.path.strip("/")
        if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?:\.git)?", path):
            raise ValueError("URL must point to a repository: https://github.com/owner/repository")
        owner, repo = path.removesuffix(".git").split("/", 1)
        if owner in {".", ".."} or repo in {".", ".."}:
            raise ValueError("Invalid repository path.")
        return f"https://github.com/{owner}/{repo.removesuffix('.git')}"

class FileHistoryRequest(AnalyzeRequest):
    file_path: str = Field(min_length=1, max_length=500)

    @field_validator("file_path")
    @classmethod
    def validate_relative_file_path(cls, value: str) -> str:
        normalized = value.replace("\\", "/").strip("/")
        if not normalized or normalized == ".." or normalized.startswith("../") or "/../" in normalized:
            raise ValueError("file_path must be a repository-relative path without parent traversal.")
        if "\x00" in normalized:
            raise ValueError("file_path contains an invalid character.")
        return normalized


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "mindtrace", "version": __version__}

@app.post("/api/analyze")
def analyze(request: AnalyzeRequest) -> dict:
    # TemporaryDirectory guarantees cleanup, including failures. Never check out or execute repository code.
    with tempfile.TemporaryDirectory(prefix="mindtrace-") as temp:
        target = Path(temp) / "repository"
        command = ["git", "-c", "protocol.file.allow=never", "clone", "--quiet", "--depth", str(request.max_commits),
                   "--filter=blob:none", "--no-checkout", "--", request.url + ".git", str(target)]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=45, check=False,
                                    env={**__import__('os').environ, "GIT_TERMINAL_PROMPT": "0", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": __import__('os').devnull, "GIT_ALLOW_PROTOCOL": "https"})
        except subprocess.TimeoutExpired as exc:
            raise HTTPException(status_code=504, detail="Repository download timed out. Try again or use a smaller history limit.") from exc
        except FileNotFoundError as exc:
            raise HTTPException(status_code=503, detail="Git is not installed on the server.") from exc
        if result.returncode != 0:
            raise HTTPException(status_code=422, detail="Could not access this public GitHub repository. Check the URL and repository visibility.")
        try:
            report = analyze_repository(target, max_commits=request.max_commits)
        except (GitError, ValueError) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        payload = report.model_dump(mode="json")
        payload["repository"] = request.url.removesuffix(".git").rstrip("/").split("/")[-1]
        payload["remote"] = request.url.removesuffix(".git")
        # Ensure commit URLs consistently use the normalized GitHub URL.
        for commit in payload["timeline"]:
            commit["commit_url"] = f"{payload['remote']}/commit/{commit['sha']}"
        return payload


@app.post("/api/file-history")
def file_history(request: FileHistoryRequest) -> list[dict]:
    """Return real, bounded history for one file in a public GitHub repository."""
    with tempfile.TemporaryDirectory(prefix="mindtrace-history-") as temp:
        target = Path(temp) / "repository"
        command = ["git", "-c", "protocol.file.allow=never", "clone", "--quiet",
                   "--depth", str(request.max_commits), "--filter=blob:none", "--no-checkout",
                   "--", request.url + ".git", str(target)]
        try:
            result = subprocess.run(
                command, capture_output=True, text=True, timeout=45, check=False,
                env={**__import__('os').environ, "GIT_TERMINAL_PROMPT": "0",
                     "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": __import__('os').devnull,
                     "GIT_ALLOW_PROTOCOL": "https"},
            )
        except subprocess.TimeoutExpired as exc:
            raise HTTPException(status_code=504, detail="Repository download timed out. Try again or use a smaller history limit.") from exc
        except FileNotFoundError as exc:
            raise HTTPException(status_code=503, detail="Git is not installed on the server.") from exc
        if result.returncode != 0:
            raise HTTPException(status_code=422, detail="Could not access this public GitHub repository. Check the URL and repository visibility.")
        try:
            entries = analyze_file_history(target, request.file_path, max_commits=request.max_commits)
        except (GitError, ValueError) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        payload = [entry.model_dump(mode="json") for entry in entries]
        base = request.url.removesuffix(".git").rstrip("/")
        for entry in payload:
            entry["commit_url"] = f"{base}/commit/{entry['sha']}"
        return payload


# Serve the no-build frontend when running from a source checkout.
_web_dir = Path(__file__).resolve().parent.parent / "web"
if _web_dir.exists():
    app.mount("/", StaticFiles(directory=_web_dir, html=True), name="web")

