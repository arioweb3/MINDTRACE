"""Shared, validated report models."""
from __future__ import annotations
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class CommitRecord(BaseModel):
    sha: str
    short_sha: str
    author: str
    date: datetime
    subject: str
    changed_files: list[str] = Field(default_factory=list)
    commit_url: str | None = None

class FileRecord(BaseModel):
    path: str
    change_count: int = Field(ge=0)

class GraphNode(BaseModel):
    id: str
    path: str
    change_count: int = Field(ge=0)

class GraphEdge(BaseModel):
    source: str
    target: str
    weight: int = Field(ge=1)

class Summary(BaseModel):
    commits_analyzed: int = Field(ge=0)
    files_touched: int = Field(ge=0)
    contributors: int = Field(ge=0)
    cochange_links: int = Field(ge=0)

class DateRange(BaseModel):
    earliest: datetime | None = None
    latest: datetime | None = None

class AnalysisReport(BaseModel):
    model_config = ConfigDict(extra="forbid")
    repository: str
    remote: str | None = None
    branch: str | None = None
    head: str | None = None
    summary: Summary
    timeline: list[CommitRecord]
    files: list[FileRecord]
    graph: dict[str, list[GraphNode] | list[GraphEdge]]
    date_range: DateRange
    notes: list[str] = Field(default_factory=list)


class FileHistoryEntry(BaseModel):
    """One historical commit affecting a file path."""
    sha: str
    short_sha: str
    author: str
    date: datetime
    subject: str
    paths: list[str] = Field(default_factory=list)
    commit_url: str | None = None
