"""Core repository archaeology engine."""
from __future__ import annotations
from collections import Counter
from datetime import datetime
from pathlib import Path
import re
from .git_reader import GitError, is_git_repository, run_git
from .graph import build_cochange_graph
from .models import AnalysisReport, CommitRecord, DateRange, FileHistoryEntry, FileRecord, Summary

MIN_COMMITS = 1
MAX_COMMITS = 2000


def _remote_url(repo: Path) -> str | None:
    value = run_git(repo, ["remote", "get-url", "origin"], check=False).strip()
    if not value:
        return None
    # Convert SSH-style GitHub remotes into browser links where possible.
    match = re.fullmatch(r"git@github\.com:([^\s]+?)(?:\.git)?", value)
    if match:
        return f"https://github.com/{match.group(1)}"
    if value.startswith("https://github.com/"):
        return value.removesuffix(".git")
    return None


def analyze_repository(path: str | Path, *, max_commits: int = 250) -> AnalysisReport:
    """Analyze a local Git checkout using bounded, read-only Git commands."""
    if not MIN_COMMITS <= max_commits <= MAX_COMMITS:
        raise ValueError(f"max_commits must be between {MIN_COMMITS} and {MAX_COMMITS}.")
    repo = Path(path).expanduser().resolve()
    if not repo.exists() or not repo.is_dir():
        raise GitError("Repository path does not exist or is not a directory.")
    if not is_git_repository(repo):
        raise GitError("The supplied directory is not a Git repository.")

    head = run_git(repo, ["rev-parse", "HEAD"], check=False).strip() or None
    branch = run_git(repo, ["branch", "--show-current"], check=False).strip() or None
    remote = _remote_url(repo)
    # Record separator and NUL delimiters keep commit metadata distinct from filenames.
    raw = run_git(repo, ["log", f"--max-count={max_commits}", "--format=%x1e%H%x1f%an%x1f%aI%x1f%s", "--name-only", "-z"], check=False)
    commits: list[CommitRecord] = []
    commit_files: list[list[str]] = []
    file_counts: Counter[str] = Counter()
    contributors: set[str] = set()
    for chunk in raw.split("\x1e"):
        chunk = chunk.strip("\n\r\x00")
        if not chunk.strip():
            continue
        parts = chunk.split("\x00")
        metadata = parts[0].strip("\n\r")
        fields = metadata.split("\x1f", 3)
        if len(fields) != 4 or not fields[0].strip():
            continue
        sha, author, date_text, subject = fields
        try:
            date = datetime.fromisoformat(date_text)
        except ValueError:
            continue
        paths = sorted({p.strip("\n\r") for p in parts[1:] if p.strip("\n\r")})
        # Git may put a newline between the formatted header and the first path.
        paths = [p for p in paths if p and not p.startswith("commit ")]
        contributors.add(author)
        file_counts.update(paths)
        commits.append(CommitRecord(sha=sha, short_sha=sha[:8], author=author, date=date,
                                    subject=subject, changed_files=paths,
                                    commit_url=f"{remote}/commit/{sha}" if remote else None))
        commit_files.append(paths)
    nodes, edges = build_cochange_graph(file_counts, commit_files)
    dates = [c.date for c in commits]
    notes = ["Co-change edges count commits in which files changed together; they do not prove direct dependency or causation.",
             f"Analysis is limited to the newest {max_commits} commits at most.",
             "Rename detection is not enabled; paths are counted as observed by Git's name-only history."]
    if not commits:
        notes.append("No commits were found. The repository may be empty or have no reachable history.")
    if any(len(set(fs)) > 40 for fs in commit_files):
        notes.append("Co-change pairs from commits touching more than 40 distinct files are skipped to bound computation.")
    return AnalysisReport(
        repository=repo.name or str(repo), remote=remote, branch=branch, head=head,
        summary=Summary(commits_analyzed=len(commits), files_touched=len(file_counts),
                        contributors=len(contributors), cochange_links=len(edges)),
        timeline=commits, files=[FileRecord(path=p, change_count=n) for p, n in file_counts.most_common(200)],
        graph={"nodes": nodes, "edges": edges},
        date_range=DateRange(earliest=min(dates) if dates else None, latest=max(dates) if dates else None),
        notes=notes)



def analyze_file_history(
    path: str | Path,
    file_path: str,
    *,
    max_commits: int = 250,
) -> list[FileHistoryEntry]:
    """Return bounded, rename-aware history for one repository-relative file.

    Git's ``--follow`` is heuristic and follows one file's rename history; it is
    not a guarantee that every historical rename can be identified.
    """
    if not MIN_COMMITS <= max_commits <= MAX_COMMITS:
        raise ValueError(f"max_commits must be between {MIN_COMMITS} and {MAX_COMMITS}.")
    repo = Path(path).expanduser().resolve()
    if not repo.exists() or not repo.is_dir():
        raise GitError("Repository path does not exist or is not a directory.")
    if not is_git_repository(repo):
        raise GitError("The supplied directory is not a Git repository.")
    normalized = file_path.replace("\\", "/").strip("/")
    if not normalized or normalized == ".." or normalized.startswith("../") or "/../" in normalized:
        raise ValueError("file_path must be a repository-relative path without parent traversal.")
    raw = run_git(
        repo,
        ["log", "--follow", f"--max-count={max_commits}",
         "--format=%x1e%H%x1f%an%x1f%aI%x1f%s", "--name-only", "-z", "--", normalized],
    )
    remote = _remote_url(repo)
    entries: list[FileHistoryEntry] = []
    for chunk in raw.split("\x1e"):
        chunk = chunk.strip("\n\r\x00")
        if not chunk.strip():
            continue
        parts = chunk.split("\x00")
        fields = parts[0].strip("\n\r").split("\x1f", 3)
        if len(fields) != 4 or not fields[0].strip():
            continue
        sha, author, date_text, subject = fields
        try:
            date = datetime.fromisoformat(date_text)
        except ValueError:
            continue
        paths = sorted({item.strip("\n\r") for item in parts[1:] if item.strip("\n\r")})
        entries.append(FileHistoryEntry(
            sha=sha, short_sha=sha[:8], author=author, date=date,
            subject=subject, paths=paths,
            commit_url=f"{remote}/commit/{sha}" if remote else None,
        ))
    return entries
