"""Bounded, read-only Git subprocess helpers."""
from __future__ import annotations
import os
import subprocess
from pathlib import Path
from typing import Sequence

class GitError(RuntimeError):
    """A safe, user-facing Git inspection error."""

DEFAULT_TIMEOUT = 20

def run_git(repo: Path, args: Sequence[str], *, timeout: int = DEFAULT_TIMEOUT, check: bool = True) -> str:
    command = ["git", "-C", str(repo), *args]
    try:
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace",
                                timeout=timeout, check=False, env={**os.environ, "GIT_OPTIONAL_LOCKS": "0",
                                "GIT_TERMINAL_PROMPT": "0", "GIT_CONFIG_NOSYSTEM": "1"})
    except subprocess.TimeoutExpired as exc:
        raise GitError(f"Git operation timed out after {timeout} seconds.") from exc
    except FileNotFoundError as exc:
        raise GitError("Git executable was not found. Install Git and try again.") from exc
    if check and result.returncode != 0:
        # Do not surface arbitrary stderr paths/configuration to API clients.
        message = result.stderr.strip().splitlines()
        safe = message[-1] if message else "Git command failed."
        if len(safe) > 240:
            safe = safe[:237] + "..."
        raise GitError(safe)
    return result.stdout

def is_git_repository(path: Path) -> bool:
    return path.is_dir() and _git_dir_check(path)

def _git_dir_check(path: Path) -> bool:
    try:
        run_git(path, ["rev-parse", "--git-dir"], timeout=3)
        return True
    except GitError:
        return False
