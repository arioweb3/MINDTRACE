from fastapi.testclient import TestClient
from mindtrace.api import app, AnalyzeRequest
from pydantic import ValidationError
import pytest

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "service": "mindtrace", "version": "0.1.0"}

def test_github_url_validation():
    request = AnalyzeRequest(url="https://github.com/owner/repository", max_commits=10)
    assert request.url == "https://github.com/owner/repository"
    for url in ["http://github.com/a/b", "https://evil.example/a/b", "https://github.com.evil.example/a/b", "https://user:pass@github.com/a/b", "https://github.com/a/b?token=x", "https://github.com/a"]:
        with pytest.raises(ValidationError):
            AnalyzeRequest(url=url)

def test_max_commit_validation():
    with pytest.raises(ValidationError): AnalyzeRequest(url="https://github.com/a/b", max_commits=3000)

def test_api_analysis_invalid_repo_returns_clear_error(monkeypatch):
    import mindtrace.api as api
    class Result:
        returncode = 128
        stderr = "not found"
    monkeypatch.setattr(api.subprocess, "run", lambda *a, **k: Result())
    response = client.post("/api/analyze", json={"url":"https://github.com/owner/nonexistent", "max_commits":5})
    assert response.status_code == 422
    assert "public GitHub repository" in response.json()["detail"]


def test_api_clone_timeout_returns_504(monkeypatch):
    import mindtrace.api as api
    def timeout(*args, **kwargs):
        raise api.subprocess.TimeoutExpired(cmd="git clone", timeout=45)
    monkeypatch.setattr(api.subprocess, "run", timeout)
    response = client.post("/api/analyze", json={"url":"https://github.com/owner/repository", "max_commits":5})
    assert response.status_code == 504
    assert "timed out" in response.json()["detail"]


def test_file_history_url_and_path_validation():
    from mindtrace.api import FileHistoryRequest
    assert FileHistoryRequest(url="https://github.com/owner/repo", file_path="src/main.py").file_path == "src/main.py"
    for file_path in ["../secret", "src/../../secret", ""]:
        with pytest.raises(ValidationError):
            FileHistoryRequest(url="https://github.com/owner/repo", file_path=file_path)


def test_file_history_clone_failure_is_clear(monkeypatch):
    import mindtrace.api as api
    class Result:
        returncode = 128
        stderr = "not found"
    monkeypatch.setattr(api.subprocess, "run", lambda *a, **k: Result())
    response = client.post("/api/file-history", json={"url":"https://github.com/owner/repo", "file_path":"src/main.py", "max_commits":5})
    assert response.status_code == 422
    assert "public GitHub repository" in response.json()["detail"]
