from pathlib import Path
import pytest
from mindtrace.engine import analyze_repository
from mindtrace.git_reader import GitError

def test_analyze_multiple_commits(git_repo: Path):
    report = analyze_repository(git_repo)
    assert report.summary.commits_analyzed == 3
    assert report.summary.files_touched == 2
    assert report.summary.contributors == 2
    assert report.head and len(report.head) >= 40
    assert report.branch == "main"
    assert report.timeline[0].subject == "Update app and docs"
    assert report.timeline[0].changed_files == ["README.md", "app.py"]
    assert report.date_range.earliest is not None and report.date_range.latest is not None

def test_most_changed_file(git_repo: Path):
    report = analyze_repository(git_repo)
    assert report.files[0].path == "app.py"
    assert report.files[0].change_count == 3

def test_empty_repository(tmp_path: Path):
    repo = tmp_path / "empty"; repo.mkdir()
    import subprocess
    subprocess.run(["git", "init", str(repo)], check=True, capture_output=True)
    report = analyze_repository(repo)
    assert report.summary.commits_analyzed == 0
    assert report.summary.files_touched == 0
    assert any("No commits" in note for note in report.notes)

def test_invalid_path(tmp_path: Path):
    with pytest.raises(GitError, match="does not exist"):
        analyze_repository(tmp_path / "missing")

def test_not_git_repository(tmp_path: Path):
    with pytest.raises(GitError, match="not a Git repository"):
        analyze_repository(tmp_path)

def test_max_commits_bounds(git_repo: Path):
    with pytest.raises(ValueError):
        analyze_repository(git_repo, max_commits=0)
    assert analyze_repository(git_repo, max_commits=1).summary.commits_analyzed == 1

def test_report_json_shape(git_repo: Path):
    payload = analyze_repository(git_repo).model_dump(mode="json")
    assert {"repository", "remote", "branch", "head", "summary", "timeline", "files", "graph", "date_range", "notes"} <= payload.keys()
    assert "nodes" in payload["graph"] and "edges" in payload["graph"]


def test_file_history_returns_real_commits(git_repo: Path):
    from mindtrace.engine import analyze_file_history
    history = analyze_file_history(git_repo, "app.py")
    assert len(history) == 3
    assert history[0].subject == "Update app and docs"
    assert all(len(item.sha) == 40 for item in history)
    assert all(item.paths for item in history)


def test_file_history_rejects_parent_traversal(git_repo: Path):
    from mindtrace.engine import analyze_file_history
    with pytest.raises(ValueError, match="repository-relative"):
        analyze_file_history(git_repo, "../outside.txt")


def test_file_history_respects_limit(git_repo: Path):
    from mindtrace.engine import analyze_file_history
    assert len(analyze_file_history(git_repo, "app.py", max_commits=1)) == 1
