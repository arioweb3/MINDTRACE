from __future__ import annotations
import os
import subprocess
from pathlib import Path
import pytest

@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    repo = tmp_path / "sample-repo"
    repo.mkdir()
    def git(*args: str, env=None) -> str:
        merged = {**os.environ, "GIT_AUTHOR_NAME": "Test Author", "GIT_AUTHOR_EMAIL": "author@example.test",
                  "GIT_COMMITTER_NAME": "Test Author", "GIT_COMMITTER_EMAIL": "author@example.test",
                  "GIT_AUTHOR_DATE": "2024-01-01T12:00:00+00:00", "GIT_COMMITTER_DATE": "2024-01-01T12:00:00+00:00"}
        if env: merged.update(env)
        return subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True, text=True, env=merged).stdout
    git("init", "-b", "main")
    (repo / "app.py").write_text("print('one')\n", encoding="utf-8")
    (repo / "README.md").write_text("hello\n", encoding="utf-8")
    git("add", "."); git("commit", "-m", "Initial structure")
    (repo / "app.py").write_text("print('two')\n", encoding="utf-8")
    git("add", "app.py"); git("commit", "-m", "Update app")
    (repo / "app.py").write_text("print('three')\n", encoding="utf-8")
    (repo / "README.md").write_text("hello world\n", encoding="utf-8")
    git("add", "."); git("commit", "-m", "Update app and docs", env={"GIT_AUTHOR_NAME":"Second Author", "GIT_AUTHOR_EMAIL":"second@example.test", "GIT_COMMITTER_NAME":"Second Author", "GIT_COMMITTER_EMAIL":"second@example.test", "GIT_AUTHOR_DATE":"2024-01-03T12:00:00+00:00", "GIT_COMMITTER_DATE":"2024-01-03T12:00:00+00:00"})
    return repo
