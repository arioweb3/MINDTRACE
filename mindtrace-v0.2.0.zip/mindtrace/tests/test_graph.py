from collections import Counter
from mindtrace.graph import build_cochange_graph

def test_cochange_weight_is_shared_commit_count():
    nodes, edges = build_cochange_graph(Counter({"a.py": 3, "b.py": 2, "c.py": 1}), [["a.py", "b.py"], ["a.py", "b.py", "c.py"], ["a.py"]])
    edge = next(e for e in edges if {e.source, e.target} == {"a.py", "b.py"})
    assert edge.weight == 2
    assert len(nodes) == 3

def test_oversized_commit_is_skipped():
    paths = [f"f{i}" for i in range(5)]
    _, edges = build_cochange_graph(Counter({p: 1 for p in paths}), [paths], max_files_per_commit=3)
    assert edges == []

def test_graph_limits():
    counts = Counter({f"f{i}": 10-i for i in range(10)})
    nodes, edges = build_cochange_graph(counts, [list(counts)], max_nodes=4, max_edges=3)
    assert len(nodes) == 4 and len(edges) <= 3
