import json
from mindtrace.cli import main

def test_cli_json_output(git_repo, monkeypatch, tmp_path, capsys):
    output = tmp_path / "report.json"
    monkeypatch.setattr("sys.argv", ["mindtrace", "analyze", str(git_repo), "--max-commits", "10", "--json", str(output)])
    main()
    assert "Report written" in capsys.readouterr().out
    data = json.loads(output.read_text(encoding="utf-8"))
    assert data["summary"]["commits_analyzed"] == 3

def test_cli_invalid_path_exit_code(monkeypatch, capsys, tmp_path):
    monkeypatch.setattr("sys.argv", ["mindtrace", "analyze", str(tmp_path / "nope")])
    import pytest
    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 2
    assert "error" in capsys.readouterr().err


def test_file_history_cli_json(git_repo, capsys):
    from mindtrace.cli import main
    import json
    import sys
    sys.argv = ["mindtrace", "file-history", str(git_repo), "app.py", "--json", "-"]
    main()
    result = json.loads(capsys.readouterr().out)
    assert len(result) == 3
    assert result[0]["subject"] == "Update app and docs"
