# MINDTRACE

**EVERY CHANGE LEAVES A TRACE.**

An interactive digital archaeology engine for exploring Git history, repository evolution, and change relationships. MINDTRACE turns actual Git metadata into a commit timeline, file-change frequency rankings, and a weighted co-change graph. It is designed to be explicit about evidence: files changed together in a commit are *co-changed*, not automatically dependent.

## Features in v0.1.0

- Read-only analysis of local Git repositories through a shared Python engine.
- Public GitHub repository analysis through a bounded temporary clone and FastAPI.
- Commit timeline with SHA, author, date, subject, changed paths, and commit links when a GitHub remote is available.
- File change counts and a bounded co-change graph weighted by the number of shared commits.
- CLI with readable summaries and JSON report output.
- Responsive dark web interface with a lightweight animated canvas, accessible report views, and interactive SVG graph.
- Automated tests, API schema, GitHub Actions, and security/contribution documentation.

## Architecture

```text
Browser ──POST /api/analyze──┐
                             ▼
CLI ────────────────► Analysis Engine ──► Git subprocess (read-only metadata)
                             │
                             ├── Shared Pydantic report models
                             └── Bounded co-change graph
```

The browser and CLI use the same `analyze_repository` engine. The API clones public GitHub repositories into `TemporaryDirectory`, limits history depth and clone time, never checks out project files, and never executes repository code. The frontend uses plain HTML/CSS/JavaScript to keep the initial release build-free and easy to run. Its central artifact is CSS-rendered rather than a WebGL scene, avoiding a heavyweight GPU dependency in the first release.

## Requirements

- Python 3.11 or newer
- Git 2.x available on `PATH`
- Internet access on the API server only when analyzing a public GitHub URL

## Install

Linux/macOS:

```bash
git clone https://github.com/YOUR-ACCOUNT/mindtrace.git
cd mindtrace
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[test]'
```

Windows PowerShell:

```powershell
git clone https://github.com/YOUR-ACCOUNT/mindtrace.git
cd mindtrace
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[test]"
```

Replace `YOUR-ACCOUNT` with the GitHub account or organization after you publish the repository. The URL above is an installation template, not a claim that MINDTRACE has already been published.

## Run the web app and API

From the repository root with dependencies installed:

```bash
uvicorn mindtrace.api:app --reload --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. Health check: `http://127.0.0.1:8000/api/health`. Interactive OpenAPI documentation: `http://127.0.0.1:8000/docs`.

Example request:

```bash
curl -X POST http://127.0.0.1:8000/api/analyze \
  -H 'Content-Type: application/json' \
  -d '{"url":"https://github.com/pallets/flask","max_commits":100}'
```

Example response shape (illustrative schema only; values below are not a claimed analysis result):

```json
{
  "repository": "repository",
  "remote": "https://github.com/owner/repository",
  "branch": "main",
  "head": "<full-commit-sha>",
  "summary": {"commits_analyzed": 1, "files_touched": 2, "contributors": 1, "cochange_links": 1},
  "timeline": [],
  "files": [],
  "graph": {"nodes": [], "edges": []},
  "date_range": {"earliest": null, "latest": null},
  "notes": []
}
```

The API returns real values at runtime; the response above is only a shape illustration.

## CLI

Analyze a local repository:

```bash
mindtrace analyze /path/to/repository
mindtrace analyze /path/to/repository --max-commits 250
mindtrace analyze /path/to/repository --json report.json

# Inspect the history of one file (Git rename-follow heuristic)
mindtrace file-history /path/to/repository src/app.py
mindtrace file-history /path/to/repository src/app.py --json file-history.json
mindtrace analyze /path/to/repository --json - > report.json
```

PowerShell example: `mindtrace analyze C:\src\my-project --max-commits 250 --json report.json`.

`--max-commits` accepts values from 1 to 2,000. CLI validation errors return exit code 2. JSON output uses the same report models as the API.

## Tests

```bash
python -m pip install -e '.[test]'
pytest
```

Tests create temporary local Git repositories and do not require GitHub access. Network timeout handling is covered by mocked subprocess behavior; live GitHub availability is not part of the default test suite.

## Evidence and limitations

- “File change count” means how many analyzed commits list that path as changed; it is not a line-count or defect metric.
- An edge weight is the number of analyzed commits where both files appear together. It does not prove direct dependency, causality, or impact.
- At most 2,000 commits are analyzed. The public API clone timeout is 45 seconds. The engine bounds graph nodes/edges and skips co-change pairs from commits with more than 40 changed paths.
- File rename tracking, historical diffs, line-level churn, contributor identity merging, and statistically validated change-point detection are not implemented in v0.1.0.
- Commit history available in a shallow clone is the history that can be observed within the requested depth.
- Empty repositories are reported with zero counts and an explanatory note.

## Security

Only public `https://github.com/owner/repository` URLs are accepted by the API. Credentials, query strings, fragments, alternate hosts, and non-HTTPS schemes are rejected. Git is invoked with argument arrays, never `shell=True`. The API does not expose local-path analysis and does not execute checked-out source or hooks intentionally. Temporary clone directories are automatically cleaned up.

Hostname validation alone is not a complete SSRF boundary. Before exposing the API to untrusted public traffic, deploy behind egress controls that restrict DNS/IP destinations to approved GitHub endpoints, block private/link-local/metadata ranges, apply per-IP rate limits and concurrency quotas, cap disk/CPU/memory, and isolate the worker in a sandbox/container. Git configuration and network behavior should be reviewed for the deployment environment. No private repository tokens are supported or required.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Report security issues privately as described in [SECURITY.md](SECURITY.md).

## License

MIT; see [LICENSE](LICENSE).

## Roadmap

See [docs/ROADMAP.md](docs/ROADMAP.md). Planned features are not represented as currently available.

### File history

Inspect a file's historical commits with Git's rename-follow heuristic:

```bash
mindtrace file-history /path/to/repository src/app.py
mindtrace file-history /path/to/repository src/app.py --json file-history.json
```

The HTTP endpoint `POST /api/file-history` accepts `url`, `file_path`, and optional `max_commits`; see `docs/API.md`. Rename tracking is heuristic, not guaranteed.

