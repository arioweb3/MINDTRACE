# Security policy

## Reporting a vulnerability

Please do not publish exploitable details in a public issue. Contact the repository maintainers through a private security advisory once the project is published. Until a public repository exists, no monitored security contact is configured.

## Security boundaries in v0.1.0

- The API accepts only public HTTPS GitHub repository URLs in owner/repository form.
- Local filesystem paths are accepted only by the local CLI, not by the API.
- Clone operations have a 45-second timeout and use a temporary directory that is cleaned up automatically.
- The server does not check out repository content or run build/test scripts.
- Git subprocesses use argument arrays and no shell; Git prompts are disabled.
- Commit history, graph nodes, graph edges, and commit counts are bounded.

## Deployment guidance

URL allowlisting is not sufficient SSRF protection on its own. For a public deployment, enforce outbound network policy at the infrastructure layer, block private/link-local/metadata IP ranges after DNS resolution, restrict Git transport, rate-limit requests, cap concurrency and disk/CPU/memory, run the API as an unprivileged user, and isolate clone workers. Consider a job queue and dedicated sandbox before accepting high-volume traffic. Private repositories and credentials are deliberately unsupported in this release.
