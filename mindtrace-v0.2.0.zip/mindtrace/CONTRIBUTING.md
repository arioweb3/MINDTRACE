# Contributing to MINDTRACE

Thanks for helping improve MINDTRACE. Keep analysis evidence-based, bounded, and clear about uncertainty.

## Development setup

Use Python 3.11+, Git, and a virtual environment. Install with `python -m pip install -e '.[test]'` and run `pytest` before submitting changes.

## Pull requests

- Explain the problem and intended behavior.
- Add tests for engine, API, CLI, or frontend behavior as appropriate.
- Keep subprocess calls argument-based and time-bounded; never use `shell=True`.
- Do not execute repository content during analysis.
- Document any new inference and its evidence/limitations.
- Avoid adding dependencies without a clear maintenance or runtime benefit.

## Style

Use type hints in Python, small focused modules, clear errors, and accessible semantic UI. Do not add synthetic repository results to the normal report flow. Any visual sample data must be explicitly labelled DEMO.
